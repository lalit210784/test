package Tests;

import org.openqa.selenium.By;
import org.testng.annotations.Test;

import io.appium.java_client.MobileElement;

public class Registration extends BaseClass {

	@Test
	public void Register()
	{
		//driver.findElement(By.id("com.ekutir.blooom:id/edit_mobileNo")).click();
	//driver.findElement(By.xpath("//*[@id=\"selectedElementContainer\"]/div/div[2]/div/div[2]/div/div/div/div/div/table/tbody/tr[2]/td[2]/text()")).click();
	    //driver.findElement(By.xpath("/hierarchy/android.widget.FrameLayout/android.widget.LinearLayout/android.widget.FrameLayout/android.widget.LinearLayout/android.widget.FrameLayout/android.widget.RelativeLayout/android.widget.LinearLayout/android.widget.LinearLayout/android.widget.LinearLayout/android.widget.LinearLayout/android.widget.EditText")).click();
	    //driver.findElement(By.id("df210cfd-e0fa-4cfe-826a-091c3c86cece")).click();
		//driver.findElement(By.xpath("//*[contains(text(),'Register')]")).click();
		
		//driver.findElement(By.xpath("//android.widget.EditText[@text='Mobile number']")).click();
		//By.xpath("//android.widget.EditText[@text='Email ID']")

		//driver.findElement(By.xpath("//android.widget.Button[@text='Register']")).click();
		
		//List<MobileElement> ls = driver.findElements(By.tagName("android.widget.EditText"));
		
		//driver.findElement(By.xpath("//android.widget.RelativeLayout[@index='2']")).click();
		//driver.findElement(By.id("com.ekutir.blooom:id/edit_mobileNo")).cl
		//Boolean bt = driver.findElement(By.xpath("//*[@id='com.ekutir.blooom:id/edit_mobileNo']")).isDisplayed();
		//System.out.println(bt);
		Boolean b = driver.findElement(By.className("android.widget.EditText")).isDisplayed();
		System.out.println(b);
		
	}
	
	
}
